/**
* Using output and escape sequences, create a bubbly fish from scratch
*/

/**
*  The BubblyFish Program.
*  @author Faustina Bui
*  @version June 16, 2023
*/

public class BubblyFish
{
   public static void main(String[] args)
   {
       System.out.println("o                 o");
       System.out.println("                 o   ");
       System.out.println("          o   ______        o");
       System.out.println("            _/  (   \\_");
       System.out.println(" _        _/  (       \\_    O");
       System.out.println("| \\_   _/   (   (    0  \\");
       System.out.println("|== \\_/   (   (          |");
       System.out.println("|=== _  (   (   (        |");
       System.out.println("|==_/ \\_  (   (          |");
       System.out.println("|_/     \\_  (   (     \\__/");
       System.out.println("           \\_  (       _/");
       System.out.println("              |  |___/");
       System.out.println("  \"          /__/");
   }
}


